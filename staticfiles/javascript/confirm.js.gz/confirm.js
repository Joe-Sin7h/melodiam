document.getElementById('id_new_password2').placeholder='Confirm Password'
document.getElementById('id_new_password1').placeholder='New Password'