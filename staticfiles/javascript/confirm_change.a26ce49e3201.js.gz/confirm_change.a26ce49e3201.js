document.getElementById('id_new_password2').placeholder='Confirm New Password'
document.getElementById('id_new_password1').placeholder='New Password'
document.getElementById('id_old_password').placeholder='Current Password'